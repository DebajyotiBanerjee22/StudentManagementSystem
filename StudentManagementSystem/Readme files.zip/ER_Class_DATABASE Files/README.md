# Student Management System - Java Project

A complete backend project built using Java SE, MySQL, JDBC, and Apache NetBeans (JDK 24) for managing students, their academic and contact details, streams, departments, and subjects.

## Project Structure

```
student-management-system/
├── src/student/management/system/
│   ├── Main.java
│   ├── Conn.java
│   ├── *.java (Model and DAO Classes)
├── lib/
│   └── mysql-connector-java-9.3.0.jar
├── SQL stmnt Student Database.txt
├── ER model.pdf
└── Editor _ Mermaid Chart-2025-05-27-181424.png
```

## How to Run

1. Open in NetBeans.
2. Ensure MySQL DB `studentdb` is running.
3. Execute SQL from `SQL stmnt Student Database.txt`.
4. Add `mysql-connector-java-9.3.0.jar` to classpath.
5. Run `Main.java`.

## Author

Debajyoti Banerjee